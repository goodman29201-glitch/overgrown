OVERGROWN - put it on the web so a Meta Quest (or any VR headset browser) can play it

The headset browser only allows VR on a real web address (https), so host these files once:

1. On a computer, go to https://app.netlify.com/drop
2. Drag this whole "overgrown-vr" folder onto the page (unzip it first).
3. Netlify gives you an address like https://something.netlify.app - open it in the
   Meta Quest Browser on the headset (type it in, or send it to yourself).
4. Click to start, then press ENTER VR (bottom right of the start screen).

Keep the four files together: index.html loads data-1.js and data-2.js from the same folder.
The game needs an internet connection (it loads three.js and a font from the web).
On a standalone headset the game switches to its lighter VR settings by itself.
